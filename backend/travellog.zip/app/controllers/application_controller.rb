class ApplicationController < ActionController::API
  include ActionController::MimeResponds
end
